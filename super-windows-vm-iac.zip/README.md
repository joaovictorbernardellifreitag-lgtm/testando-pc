# Super Windows VM - Infraestrutura como Código (IaC) com Terraform

Este projeto utiliza **Terraform** para provisionar uma Máquina Virtual (VM) de alto desempenho no **Google Cloud Platform (GCP)**, simulando as especificações de um PC gamer (i5-12400F/RTX 3060/16GB RAM) conforme solicitado.

## Especificações da VM

| Componente Solicitado | Especificação Implementada (GCP) | Detalhes |
| :--- | :--- | :--- |
| **Processador (CPU)** | `n1-standard-4` (4 vCPUs) | 4 vCPUs de alto desempenho. |
| **Placa de Vídeo (GPU)** | **NVIDIA Tesla T4** (1x) | GPU de nível profissional, equivalente ou superior à RTX 3060 para estações de trabalho virtuais. |
| **Memória RAM** | 15 GB | Próximo aos 16 GB solicitados. |
| **Armazenamento** | SSD (NVMe) de 500 GB | Disco de inicialização de alto desempenho. |
| **Sistema Operacional** | Windows Server 2022 | Imagem de servidor com experiência de desktop, licenciada para nuvem. |

## Pré-requisitos

1.  **Conta GCP:** Uma conta ativa no Google Cloud Platform com faturamento habilitado.
2.  **GCP CLI:** O `gcloud` CLI instalado e autenticado em sua máquina local.
3.  **Terraform:** O Terraform CLI instalado.

## Como Usar

1.  **Clone o Repositório:**
    \`\`\`bash
    git clone [URL_DO_REPOSITORIO]
    cd windows-vm-iac
    \`\`\`

2.  **Autentique-se no GCP:**
    \`\`\`bash
    gcloud auth application-default login
    \`\`\`

3.  **Crie um arquivo `terraform.tfvars`** para definir o ID do seu projeto:
    \`\`\`hcl
    gcp_project_id = "seu-id-do-projeto-gcp"
    # Opcional: defina a zona se quiser usar uma diferente
    # gcp_zone = "us-west1-b"
    \`\`\`

4.  **Inicialize o Terraform:**
    \`\`\`bash
    terraform init
    \`\`\`

5.  **Revise o Plano de Execução:**
    \`\`\`bash
    terraform plan
    \`\`\`

6.  **Aplique as Mudanças:**
    \`\`\`bash
    terraform apply
    \`\`\`

7.  **Obtenha o IP da VM:**
    O IP público será exibido na saída do `terraform apply`.

8.  **Conecte-se à VM (RDP):**
    *   No console do GCP, vá para a instância criada.
    *   Clique em **"Set Windows password"** para criar uma senha para o usuário `Administrator`.
    *   Use um cliente RDP (Remote Desktop Protocol) com o IP público e as credenciais para acessar sua VM.

## Limpeza

Para destruir todos os recursos criados e evitar cobranças:

\`\`\`bash
terraform destroy
\`\`\`
